// يتحقق أن كل أصل مذكور في الإعدادات موجود فعلاً، وأن أبعاد الشرائح تطابق ملفات PNG.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { ASSETS, SHEETS } from '../public/config.js';

const file = (u) => new URL('../public' + u, import.meta.url);
test('كل مسارات الأصول موجودة', () => {
  for (const u of [ASSETS.bg.day, ASSETS.bg.night, ASSETS.audio, ...Object.values(SHEETS).map((s) => s.url), '/game.js', '/layout.js', '/index.html']) assert.ok(existsSync(file(u)), u);
});
test('أبعاد الشرائح = (الأعمدة × عرض الإطار) × (الصفوف × ارتفاعه) وكل حركة داخل الشريحة', () => {
  for (const [k, s] of Object.entries(SHEETS)) {
    const b = readFileSync(file(s.url)); assert.equal(b.readUInt32BE(16), s.cols * s.w, k + ' width'); assert.equal(b.readUInt32BE(20), s.rows * s.h, k + ' height');
    for (const [n, a] of Object.entries(s.anim ?? {})) { assert.ok(a.row < s.rows && a.ms.length <= s.cols, k + '.' + n); assert.ok(a.ms.every((m) => m > 0)); }
  }
});
