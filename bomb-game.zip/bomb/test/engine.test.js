import test from 'node:test';
import assert from 'node:assert/strict';
import { Game, norm, isCorrect } from '../engine.js';

// أسئلة الاختبار معرَّفة هنا فقط (لا علاقة لها ببنك أسئلة اللعبة)
const single = (i) => ({ id: 's' + i, text: 'س' + i, cat: 'عام', d: 1, a: 'ج' + i, alt: [] });         // الشكل القديم: إجابة واحدة
const multi = { id: 'm1', text: 'اذكر ثلاثاً', cat: 'عام', d: 1, answers: ['أ', ['ب', 'bee'], 'ج'] };   // ثلاث إجابات مطلوبة
const need2 = { id: 'm2', text: 'اذكر اثنتين', cat: 'عام', d: 1, answers: ['أ', 'ب', 'ج', 'د'], need: 2 };
const mk = (n = 3, o = {}) => {
  const c = { t: 0 };
  const g = new Game({ players: Array.from({ length: n }, (_, i) => ({ id: 'P' + i, name: 'لاعب' + i })), hearts: o.hearts ?? 3, turnMs: 1000, attackMs: 500,
    smallRoom: 4, questions: o.qs ?? [multi, single(2), single(3)], now: () => c.t, rand: () => 0 });
  return [g, c];
};
const cur = (g) => g.players[g.cur].id;
const say = (g, text) => g.submit(cur(g), g.turn.id, text, g.qv);
const hp = (g) => g.players.map((p) => p.hearts);
const fail = (g, c) => { c.t = g.turn.deadline; g.tick(); c.t = g.attack.endsAt; g.tick(); };   // ينتهي المؤقت ثم ينتهي الهجوم

test('سؤال بإجابة واحدة: الصحيحة تكمله وتنقل السؤال مرة واحدة', () => {
  const [g] = mk(3, { qs: [single(1), single(2)] });
  assert.deepEqual(say(g, 'ج1'), { ok: true, correct: true });
  assert.equal(g.q.id, 's2'); assert.equal(g.qv, 2); assert.equal(cur(g), 'P1');
});

test('عدة إجابات: الجزئية تبقي السؤال وتنقل القنبلة وتعيد المؤقت؛ والاكتمال ينقل السؤال', () => {
  const [g, c] = mk(); c.t = 300;
  assert.equal(say(g, 'أ').correct, true);
  assert.equal(g.q.id, 'm1'); assert.equal(g.qv, 1); assert.equal(cur(g), 'P1'); assert.equal(g.turn.deadline, 1300);
  assert.equal(say(g, 'bee').correct, true);                       // بديل مكتوب بصيغة أخرى
  assert.equal(g.q.id, 'm1'); assert.equal(g.done.size, 2);
  assert.equal(say(g, 'ج').correct, true);
  assert.equal(g.q.id, 's2'); assert.equal(g.qv, 2); assert.equal(g.done.size, 0); assert.equal(cur(g), 'P0');   // السؤال الجديد يبدأ بعدّاد نظيف
});

test('المكرر (حالة الأحرف/المسافات/التشكيل) لا يُحتسب ولا عقوبة ولا نقل', () => {
  const [g, c] = mk(); c.t = 100; say(g, 'أ');
  const before = { ...g.turn };
  assert.deepEqual(say(g, '  أَ '), { ok: true, correct: false, dup: true });
  assert.equal(say(g, 'BEE').correct, true);                       // الحالة لا تهم
  assert.deepEqual(say(g, ' bee '), { ok: true, correct: false, dup: true });
  assert.equal(g.done.size, 2); assert.deepEqual(hp(g), [3, 3, 3]);
  assert.equal(g.turn.id, before.id + 1);                          // الدور تغيّر مرة واحدة فقط (بعد BEE)
});

test('الخاطئة: لا قلب ولا إعادة مؤقت ولا نقل ولا تغيير سؤال، ويمكن التصحيح فوراً', () => {
  const [g, c] = mk(); const before = { ...g.turn }; c.t = 400;
  assert.deepEqual(say(g, 'خطأ'), { ok: true, correct: false });
  assert.deepEqual(g.turn, before); assert.deepEqual(hp(g), [3, 3, 3]); assert.equal(g.q.id, 'm1'); assert.equal(cur(g), 'P0');
  assert.equal(say(g, 'ج').correct, true);
});

test('need أقل من عدد الإجابات: يكتمل السؤال عند بلوغه', () => {
  const [g] = mk(3, { qs: [need2, single(2)] });
  say(g, 'د'); assert.equal(g.q.id, 'm2'); say(g, 'أ'); assert.equal(g.q.id, 's2');
});

test('التزامن: إرسال الإجابة المكمِّلة مرتين لا ينقل السؤال مرتين', () => {
  const [g] = mk(3, { qs: [single(1), single(2), single(3)] });
  const id = g.turn.id;
  assert.equal(g.submit('P0', id, 'ج1', 1).correct, true);
  assert.deepEqual(g.submit('P0', id, 'ج1', 1), { ok: false, why: 'stale' });   // رسالة مكررة بسبب الشبكة
  assert.equal(g.qv, 2); assert.equal(g.q.id, 's2');
});

test('الإجابات القديمة (دور أو إصدار سؤال قديم) لا تؤثر في السؤال الجديد', () => {
  const [g] = mk(3, { qs: [single(1), single(2), single(3)] });
  const oldTurn = g.turn.id; say(g, 'ج1');                         // انتقلنا إلى s2 (qv=2)
  assert.equal(g.submit('P1', oldTurn, 'ج2', 1).why, 'stale');
  assert.equal(g.submit('P1', g.turn.id, 'ج2', 1).why, 'stale');   // دور صحيح لكن إصدار سؤال قديم
  assert.equal(g.q.id, 's2'); assert.equal(g.qv, 2);
  assert.equal(g.submit('P1', g.turn.id, 'ج2', 2).correct, true);
});

test('هجوم الرامي: ينتهي المؤقت فيبدأ الهجوم وتُغلق الإجابات، ويُطبَّق الضرر مرة واحدة فقط', () => {
  const [g, c] = mk(); c.t = 1000; g.tick();
  assert.equal(g.attack.pid, 'P0'); assert.deepEqual(hp(g), [3, 3, 3]); assert.equal(g.view().turn.atk.total, 500);
  assert.equal(say(g, 'أ').why, 'late');                           // إجابة أثناء الهجوم مرفوضة
  c.t = 1499; g.tick(); assert.deepEqual(hp(g), [3, 3, 3]);
  c.t = 1500; g.tick(); g.tick(); g.tick();
  assert.deepEqual(hp(g), [2, 3, 3]); assert.equal(g.players[0].booms, 1); assert.equal(cur(g), 'P1'); assert.equal(g.attack, null);
  assert.equal(g.turn.deadline, 2500);
});

test('إجابة متأخرة أو من غير صاحب الدور لا تؤثر', () => {
  const [g, c] = mk(); const id = g.turn.id; c.t = 1000;
  assert.equal(g.submit('P0', id, 'أ', 1).why, 'late');
  c.t = 1500; assert.equal(g.submit('P0', id, 'أ', 1).why, 'stale');
  assert.equal(g.submit('P2', g.turn.id, 'أ', 1).why, 'stale');
  assert.deepEqual(hp(g), [2, 3, 3]); assert.equal(g.players[0].correct, 0);
});

test('غرفة صغيرة: عودة القنبلة إلى لاعب فشل سابقاً تنقل السؤال مرة واحدة', () => {
  const [g, c] = mk(3); fail(g, c);                                 // P0 يفشل
  assert.equal(g.q.id, 'm1'); assert.equal(g.qv, 1); assert.equal(cur(g), 'P1');
  say(g, 'أ'); say(g, 'ب');                                         // P1 وP2 يجيبان؛ الناقص إجابة واحدة
  assert.equal(g.qv, 2); assert.equal(g.q.id, 's2'); assert.equal(cur(g), 'P0');   // عادت إلى P0 فانتقل السؤال (بلا اعتبار الناقص «صحيحاً»)
  assert.equal(g.done.size, 0); assert.equal(g.ev.at(-1).t === 'skip', true); assert.deepEqual(g.ev.at(-1).a, ['ج']);
  say(g, 'ج2'); assert.equal(g.qv, 3);                              // لا انتقال إضافي مخفي
});

test('غرفة صغيرة: إن أكمل الآخرون المطلوب قبل عودة القنبلة، لا ينتقل السؤال مرة ثانية', () => {
  const [g, c] = mk(3, { qs: [need2, single(2), single(3)] }); fail(g, c);   // P0 يفشل
  say(g, 'أ'); say(g, 'ب');                                         // الآخران يكملان (need=2)
  assert.equal(g.q.id, 's2'); assert.equal(g.qv, 2); assert.equal(cur(g), 'P0');   // انتقال واحد فقط
  assert.equal(g.ev.filter((e) => e.t === 'skip').length, 0);
});

test('غرفة عادية (4 لاعبين فأكثر): الفشل لا يغيّر السؤال ولو عادت القنبلة للفاشل', () => {
  const [g, c] = mk(4); fail(g, c);                                 // P0 يفشل
  say(g, 'أ'); say(g, 'ب'); fail(g, c);                             // P3 يفشل أيضاً
  assert.equal(cur(g), 'P0'); assert.equal(g.q.id, 'm1'); assert.equal(g.qv, 1);
  say(g, 'ج'); assert.equal(g.q.id, 's2');
});

test('الإقصاء: من نفدت قلوبه يُتخطّى ولا يعود، وتنتهي المباراة بفائز واحد', () => {
  const [g, c] = mk(4, { hearts: 1 }); fail(g, c);                  // P0 يخرج (3 متبقين = غرفة صغيرة)
  const order = [];
  for (let i = 0; i < 3; i++) { order.push(cur(g)); say(g, ['أ', 'ب', 'ج', 'ج2'][i]); }
  assert.deepEqual(order, ['P1', 'P2', 'P3']);
  const [g2, c2] = mk(2, { hearts: 1 }); fail(g2, c2);
  assert.equal(g2.status, 'over'); assert.equal(g2.winner, 'P1'); assert.equal(g2.turn, null); assert.equal(g2.attack, null);
  assert.equal(g2.submit('P1', 2, 'أ', 1).why, 'over'); assert.equal(g2.due(), null);
});

test('مغادرة صاحب القنبلة أثناء الهجوم: يُلغى الهجوم بلا ضرر ولا فشل', () => {
  const [g, c] = mk(); c.t = 1000; g.tick(); assert.ok(g.attack);
  g.leave('P0');
  assert.equal(g.attack, null); assert.deepEqual(hp(g), [3, 3, 3]); assert.equal(cur(g), 'P1'); assert.equal(g.failed.size, 0);
  g.leave('P1'); assert.equal(g.status, 'over'); assert.equal(g.winner, 'P2');
});

test('حالة اللعبة لا تكشف الإجابات غير المكتشفة', () => {
  const [g] = mk(); say(g, 'أ');
  const j = JSON.stringify(g.view());
  assert.ok(j.includes('"أ"')); assert.ok(!j.includes('"ب"') && !j.includes('bee') && !j.includes('"ج"'));
});

test('تطبيع الإجابات العربية', () => {
  assert.equal(norm('الْقَاهِرَة'), norm('قاهرة')); assert.equal(norm('أحمد'), norm('احمد'));
  assert.ok(isCorrect({ a: '7', alt: ['سبعة'] }, '٧')); assert.ok(isCorrect({ a: 'نيوتن' }, ' نيـــوتن '));
  assert.ok(!isCorrect({ a: 'مصر' }, 'سوريا')); assert.ok(!isCorrect({ a: 'مصر' }, ''));
});
