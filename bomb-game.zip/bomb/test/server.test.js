// اختبار تكامل حقيقي: عدة عملاء يتصلون بالخادم عبر HTTP + SSE (أسئلة الاختبار معرَّفة هنا فقط).
import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server.js';

const Q = { id: 'm1', text: 'اذكر ثلاثاً', cat: 'عام', d: 1, answers: ['أ', ['ب', 'bee'], 'ج'] };
const app = createApp({ minSec: 1, attackMs: () => 300, questions: [Q] });
await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${app.server.address().port}`;
test.after(() => app.close());

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const post = async (path, body) => { const r = await fetch(base + path, { method: 'POST', body: JSON.stringify(body) }); return { status: r.status, ...(await r.json()) }; };
const until = async (f, ms = 8000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const v = f(); if (v) return v; await sleep(10); } throw new Error('انتهت مهلة الانتظار'); };

async function watch(s) {
  const ac = new AbortController(), w = { last: null, stop: () => ac.abort() };
  const res = await fetch(`${base}/api/events?code=${s.code}&token=${s.token}`, { signal: ac.signal });
  (async () => {
    const rd = res.body.getReader(), dec = new TextDecoder(); let buf = '';
    try {
      for (;;) {
        const { value, done } = await rd.read(); if (done) return;
        buf += dec.decode(value, { stream: true });
        let i; while ((i = buf.indexOf('\n\n')) >= 0) { const m = buf.slice(0, i); buf = buf.slice(i + 2); if (m.startsWith('data: ')) w.last = JSON.parse(m.slice(6)); }
      }
    } catch {}
  })();
  return w;
}
async function room(names) {
  const h = await post('/api/create', { name: names[0] }), ps = [h];
  for (const n of names.slice(1)) ps.push(await post('/api/join', { code: h.code, name: n }));
  const ws = []; for (const p of ps) ws.push(await watch(p));
  await until(() => ws.every((w) => w.last?.players.length === names.length));
  return { ps, ws };
}

test('ثلاثة عملاء: عدة إجابات، مكرر، متأخر، هجوم الرامي بضرر واحد، اكتمال السؤال، تطابق الحالة، إعادة اتصال', async () => {
  const { ps: [A, B, C], ws: [wa, wb, wc] } = await room(['أحمد', 'بسمة', '<b>جمال</b>']);
  assert.ok(!wc.last.players[2].name.includes('<'));                                    // تنظيف النصوص
  assert.equal((await post('/api/settings', { ...B, hearts: 9 })).status, 403);         // غير المضيف
  assert.equal((await post('/api/start', B)).status, 403);
  assert.equal((await post('/api/settings', { ...A, hearts: 2, sec: 2 })).status, 200);
  await until(() => wb.last.s.hearts === 2 && wb.last.s.sec === 2);
  await post('/api/start', A);
  await until(() => [wa, wb, wc].every((w) => w.last.phase === 'playing'));

  const g = () => wa.last.game, ans = (P, text) => post('/api/answer', { ...P, turnId: g().turn.id, qv: g().qv, text });
  const t0 = g().turn; assert.equal(t0.pid, A.id); assert.equal(g().q.need, 3);
  assert.deepEqual(await ans(A, 'xyz'), { status: 200, ok: true, correct: false });      // خاطئة: إعادة المحاولة
  await sleep(60); assert.equal(g().turn.id, t0.id); assert.deepEqual(g().players.map((p) => p.hearts), [2, 2, 2]);
  assert.equal((await ans(A, 'أ')).correct, true);
  await until(() => g().turn.pid === B.id); assert.deepEqual(g().q.done, ['أ']); assert.equal(g().qv, 1);
  assert.equal((await post('/api/answer', { ...A, turnId: t0.id, qv: 1, text: 'ب' })).why, 'stale');   // دور قديم
  const t1 = g().turn.id; assert.equal((await ans(B, '  أ ')).dup, true);                // مكرر
  assert.equal(g().turn.id, t1);
  assert.equal((await ans(B, 'BEE')).correct, true);                                      // بديل + حالة أحرف
  await until(() => g().turn.pid === C.id); assert.equal(g().q.done.length, 2);

  await until(() => g().turn.atk && g().turn.pid === C.id);                               // انتهى المؤقت: يبدأ هجوم الرامي
  assert.equal((await ans(C, 'ج')).why, 'late');                                          // الإجابات مغلقة أثناء الهجوم
  assert.deepEqual(g().players.map((p) => p.hearts), [2, 2, 2]);                          // لا ضرر قبل نهاية الهجوم
  await until(() => g().players[2].hearts === 1 && !g().turn.atk);
  assert.deepEqual(g().players.map((p) => p.hearts), [2, 2, 1]); assert.equal(g().turn.pid, A.id); assert.equal(g().q.done.length, 2);   // قلب واحد فقط، والسؤال باقٍ

  assert.equal((await ans(A, 'ج')).correct, true);                                        // اكتملت الإجابات الثلاث
  await until(() => g().qv === 2); assert.equal(g().q.done.length, 0); assert.equal(g().turn.pid, B.id);

  await sleep(50);
  const core = (w) => JSON.stringify([w.last.game.players, w.last.game.q, w.last.game.qv, w.last.game.turn.pid, w.last.game.turn.id]);
  assert.equal(core(wa), core(wb)); assert.equal(core(wb), core(wc));                    // الحالة متطابقة
  wb.stop(); const wb2 = await watch(B); await until(() => wb2.last);                     // إعادة اتصال
  assert.equal(core(wb2), core(wa));
  [wa, wb2, wc].forEach((w) => w.stop());
});

test('الإقصاء والفائز ومنع الانضمام المتأخر وإعادة اللعب', async () => {
  const { ps: [A, B], ws: [wa, wb] } = await room(['أ', 'ب']);
  await post('/api/settings', { ...A, hearts: 1, sec: 1 });
  await post('/api/start', A);
  assert.equal((await post('/api/join', { code: A.code, name: 'متأخر' })).status, 409);
  await until(() => wa.last.phase === 'over');
  const g = wa.last.game; assert.equal(g.winner, B.id); assert.equal(g.players[0].hearts, 0); assert.equal(g.players[0].booms, 1);
  assert.equal((await post('/api/restart', B)).status, 403);
  assert.equal((await post('/api/restart', A)).status, 200);
  await until(() => wa.last.phase === 'lobby' && wa.last.players.length === 2);
  assert.equal((await post('/api/join', { code: 'ZZZZZ', name: 'س' })).status, 404);
  [wa, wb].forEach((w) => w.stop());
});

test('الملفات الثابتة: الأنواع، Range للصوت (iOS)، ومنع الخروج من public', async () => {
  const idx = await fetch(base + '/'); assert.equal(idx.status, 200); assert.match(idx.headers.get('content-type'), /text\/html/);
  assert.match((await fetch(base + '/game.js')).headers.get('content-type'), /text\/javascript/);
  assert.equal((await fetch(base + '/Desert_day.png')).headers.get('content-type'), 'image/png');
  const r = await fetch(base + '/Desert_sound.mp3', { headers: { range: 'bytes=0-99' } });
  assert.equal(r.status, 206); assert.match(r.headers.get('content-range'), /^bytes 0-99\/\d+$/); assert.equal((await r.arrayBuffer()).byteLength, 100);
  for (const bad of ['/engine.js', '/server.js', '/package.json', '/..%2fserver.js', '/%2e%2e/server.js', '/.env.example']) assert.equal((await fetch(base + bad)).status, 404, bad);
});
