import test from 'node:test';
import assert from 'node:assert/strict';
import { layout, facing } from '../public/layout.js';
import { attackPlan, ATTACK } from '../public/config.js';

const o = { vw: 18, vh: 40, minW: 56, nameH: 24, heartsH: 22, perW: 60, aw: 48, ah: 51 };
const boxesOverlap = (L) => L.slots.some((p, i) => L.slots.some((q, j) => j > i && Math.abs(p.x - q.x) < L.box.w && Math.abs(p.y - q.y) < L.box.h));

test('اللاعب المحلي دائماً في الأسفل عند كل عميل، والترتيب الدائري ثابت', () => {
  const ids = ['a', 'b', 'c', 'd', 'e'];
  for (const me of ids) {
    const L = layout(ids, me, 390, 430, o), mine = L.slots.find((s) => s.id === me);
    assert.ok(Math.abs(mine.x - L.cx) < 1); assert.equal(mine.y, Math.max(...L.slots.map((s) => s.y)));
    assert.equal(mine.dir, 'north');                                    // ينظر نحو المركز (للأعلى)
    const next = ids[(ids.indexOf(me) + 1) % ids.length];                // التالي في الدور = الأقرب باتجاه عقارب الساعة (يسار الأسفل)
    assert.ok(L.slots.find((s) => s.id === next).x < L.cx);
  }
});

test('عدد الخانات = عدد اللاعبين (لا خانات فارغة)، بلا تداخل ولا تقاطع مع الرامي', () => {
  for (const [W, H] of [[390, 430], [1280, 560]]) for (let n = 2; n <= 8; n++) {
    const ids = Array.from({ length: n }, (_, i) => 'p' + i), L = layout(ids, 'p0', W, H, o);
    assert.equal(L.slots.length, n); assert.ok(!boxesOverlap(L), `overlap n=${n} ${W}x${H}`);
  }
  assert.ok(!boxesOverlap(layout(Array.from({ length: 20 }, (_, i) => 'p' + i), 'p0', 1280, 560, o)));
});

test('الشاشة الصغيرة تقلّل المقياس بأعداد صحيحة (بلا تنعيم)', () => {
  const L = layout(['a', 'b', 'c', 'd'], 'a', 390, 330, o), D = layout(['a', 'b'], 'a', 1280, 700, o);
  assert.ok(Number.isInteger(L.s) && Number.isInteger(D.s)); assert.ok(D.s >= L.s);
});

test('الالتفات نحو المركز', () => {
  assert.equal(facing(0, 100, 0, 0), 'north'); assert.equal(facing(0, -100, 0, 0), 'south');
  assert.equal(facing(-100, 0, 0, 0), 'east'); assert.equal(facing(100, 0, 0, 0), 'west');
});

test('خطة الهجوم تتبع مؤقت الغرفة وتبقى ضمن حد معقول', () => {
  const a = attackPlan(5000), b = attackPlan(60000);
  assert.ok(b.idle >= a.idle && b.total >= a.total);
  assert.equal(a.total, a.move + a.reload + a.idle + a.release + a.arrow); assert.ok(a.total < 10000);
  assert.ok(ATTACK.speed > 0);
});
